# WSConnect Zabbix MCP Bridge

Servidor MCP em Python para administrar o laboratorio Zabbix 7.0.6 em `https://noc.wsconect.com.br`.

## Ferramentas incluídas

- Saude/versao da API
- Listar/criar grupos
- Listar templates
- Listar/criar/atualizar hosts
- Vincular templates
- Criar/atualizar macros
- Criar items
- Criar triggers
- Listar problemas
- Criar/atualizar mapas
- Chamada JSON-RPC generica para os demais metodos
- Exclusoes bloqueadas por padrao

## Implantacao no host Docker

```bash
unzip zabbix-mcp-bridge.zip
cd zabbix-mcp-bridge
cp .env.example .env
nano .env
```

No `.env`, substitua apenas:

```env
ZABBIX_API_TOKEN=seu_token_real
```

Proteja o segredo e suba o container:

```bash
chmod 600 .env
docker compose up -d --build
docker compose logs -f zabbix-mcp
```

O endpoint MCP fica localmente em:

```text
http://127.0.0.1:8000/mcp
```

O bind para `127.0.0.1` e intencional. Nao publique a porta 8000 diretamente na Internet. Para acesso externo, coloque Caddy, Nginx ou Cloudflare Access na frente e exija autenticacao.

## Teste da API Zabbix no PowerShell

O valor do token deve permanecer apenas na variavel local da sessao:

```powershell
$token = Read-Host "Token Zabbix"
$body = @{
  jsonrpc = "2.0"
  method = "host.get"
  params = @{ output = @("hostid", "host", "name") }
  auth = $token
  id = 1
} | ConvertTo-Json -Depth 10
Invoke-RestMethod -Uri "https://noc.wsconect.com.br/api_jsonrpc.php" -Method Post -ContentType "application/json-rpc" -Body $body
Remove-Variable token
```

## Teste do MCP

Use o MCP Inspector em uma maquina com Node.js:

```bash
npx -y @modelcontextprotocol/inspector
```

Conecte ao endpoint `http://127.0.0.1:8000/mcp` e execute primeiro:

1. `zabbix_health`
2. `zabbix_list_hosts`
3. `zabbix_list_templates`

So depois teste escrita com um grupo de laboratorio.

## Operacoes destrutivas

Por padrao, chamadas `.delete` feitas por `zabbix_raw_call` sao bloqueadas. Para uma janela controlada:

```env
ALLOW_DANGEROUS=true
```

Depois da manutencao, volte para `false` e reinicie:

```bash
docker compose up -d
```

## Autenticacao no Zabbix 7.0.6

Este projeto usa `ZABBIX_AUTH_MODE=body`, enviando o token no campo JSON-RPC `auth`. Isso evita incompatibilidade conhecida do cabecalho Bearer em releases anteriores ao conserto da linha 7.0.

## Conexao a um cliente MCP

O formato exato depende do cliente. Para clientes locais que aceitam URL Streamable HTTP, informe:

```text
http://127.0.0.1:8000/mcp
```

Se o cliente estiver em outra maquina, use um dominio HTTPS protegido por autenticacao e proxy reverso. Nunca exponha o endpoint MCP sem uma camada de controle de acesso.
