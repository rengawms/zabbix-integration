import os
import json
from typing import Any

import httpx
from fastmcp import FastMCP

ZABBIX_URL = os.getenv("ZABBIX_URL", "https://noc.wsconect.com.br").rstrip("/")
ZABBIX_API_URL = os.getenv("ZABBIX_API_URL", f"{ZABBIX_URL}/api_jsonrpc.php")
ZABBIX_API_TOKEN = os.getenv("ZABBIX_API_TOKEN", "")
ZABBIX_VERIFY_TLS = os.getenv("ZABBIX_VERIFY_TLS", "true").lower() in {"1", "true", "yes"}
ZABBIX_AUTH_MODE = os.getenv("ZABBIX_AUTH_MODE", "body").lower()  # body or bearer
ALLOW_DANGEROUS = os.getenv("ALLOW_DANGEROUS", "false").lower() in {"1", "true", "yes"}
REQUEST_TIMEOUT = float(os.getenv("REQUEST_TIMEOUT", "30"))

mcp = FastMCP("WSConnect Zabbix MCP")


def _api(method: str, params: dict[str, Any] | list[Any] | None = None, auth: bool = True) -> Any:
    if auth and not ZABBIX_API_TOKEN:
        raise RuntimeError("ZABBIX_API_TOKEN nao configurado.")

    payload: dict[str, Any] = {
        "jsonrpc": "2.0",
        "method": method,
        "params": params or {},
        "id": 1,
    }
    headers = {"Content-Type": "application/json-rpc"}
    if auth:
        if ZABBIX_AUTH_MODE == "bearer":
            headers["Authorization"] = f"Bearer {ZABBIX_API_TOKEN}"
        else:
            payload["auth"] = ZABBIX_API_TOKEN

    with httpx.Client(verify=ZABBIX_VERIFY_TLS, timeout=REQUEST_TIMEOUT) as client:
        response = client.post(ZABBIX_API_URL, headers=headers, json=payload)
        response.raise_for_status()
        data = response.json()

    if "error" in data:
        err = data["error"]
        raise RuntimeError(f"Zabbix API {err.get('code')}: {err.get('message')} - {err.get('data')}")
    return data.get("result")


def _require_dangerous(operation: str) -> None:
    if not ALLOW_DANGEROUS:
        raise PermissionError(
            f"Operacao '{operation}' bloqueada. Defina ALLOW_DANGEROUS=true somente durante manutencao controlada."
        )


@mcp.tool
def zabbix_health() -> dict[str, Any]:
    """Testa a API e retorna a versao, sem exigir autenticacao."""
    return {"url": ZABBIX_API_URL, "version": _api("apiinfo.version", auth=False)}


@mcp.tool
def zabbix_list_host_groups(search: str = "") -> Any:
    """Lista grupos de hosts. search filtra pelo nome."""
    params: dict[str, Any] = {"output": ["groupid", "name"], "sortfield": "name"}
    if search:
        params["search"] = {"name": search}
        params["searchWildcardsEnabled"] = True
    return _api("hostgroup.get", params)


@mcp.tool
def zabbix_create_host_group(name: str) -> Any:
    """Cria um grupo de hosts."""
    return _api("hostgroup.create", {"name": name})


@mcp.tool
def zabbix_list_templates(search: str = "") -> Any:
    """Lista templates disponiveis. search filtra por nome tecnico ou visivel."""
    params: dict[str, Any] = {
        "output": ["templateid", "host", "name"],
        "sortfield": "name",
    }
    if search:
        params["search"] = {"host": search, "name": search}
        params["searchByAny"] = True
        params["searchWildcardsEnabled"] = True
    return _api("template.get", params)


@mcp.tool
def zabbix_list_hosts(search: str = "", group_id: str = "") -> Any:
    """Lista hosts, interfaces, grupos e templates vinculados."""
    params: dict[str, Any] = {
        "output": ["hostid", "host", "name", "status"],
        "selectInterfaces": ["interfaceid", "type", "main", "useip", "ip", "dns", "port", "available", "error"],
        "selectGroups": ["groupid", "name"],
        "selectParentTemplates": ["templateid", "host", "name"],
        "sortfield": "name",
    }
    if search:
        params["search"] = {"host": search, "name": search}
        params["searchByAny"] = True
        params["searchWildcardsEnabled"] = True
    if group_id:
        params["groupids"] = [group_id]
    return _api("host.get", params)


@mcp.tool
def zabbix_create_host(
    host: str,
    visible_name: str,
    group_ids: list[str],
    ip: str,
    interface_type: int = 1,
    port: str = "10050",
    template_ids: list[str] | None = None,
    dns: str = "",
    use_ip: bool = True,
    enabled: bool = True,
    description: str = "Criado pelo WSConnect Zabbix MCP",
) -> Any:
    """Cria host. interface_type: 1 Agent, 2 SNMP, 3 IPMI, 4 JMX."""
    interface: dict[str, Any] = {
        "type": interface_type,
        "main": 1,
        "useip": 1 if use_ip else 0,
        "ip": ip,
        "dns": dns,
        "port": port,
    }
    if interface_type == 2:
        interface["details"] = {"version": 2, "bulk": 1, "community": "{$SNMP_COMMUNITY}"}

    params: dict[str, Any] = {
        "host": host,
        "name": visible_name or host,
        "status": 0 if enabled else 1,
        "description": description,
        "interfaces": [interface],
        "groups": [{"groupid": gid} for gid in group_ids],
    }
    if template_ids:
        params["templates"] = [{"templateid": tid} for tid in template_ids]
    return _api("host.create", params)


@mcp.tool
def zabbix_update_host(host_id: str, name: str = "", enabled: bool | None = None, description: str = "") -> Any:
    """Atualiza nome visivel, status e/ou descricao de um host."""
    params: dict[str, Any] = {"hostid": host_id}
    if name:
        params["name"] = name
    if enabled is not None:
        params["status"] = 0 if enabled else 1
    if description:
        params["description"] = description
    return _api("host.update", params)


@mcp.tool
def zabbix_link_templates(host_id: str, template_ids: list[str]) -> Any:
    """Vincula templates a um host preservando os vinculos existentes."""
    existing = _api("host.get", {"hostids": [host_id], "output": ["hostid"], "selectParentTemplates": ["templateid"]})
    if not existing:
        raise ValueError(f"Host {host_id} nao encontrado")
    current = {t["templateid"] for t in existing[0].get("parentTemplates", [])}
    merged = sorted(current.union(template_ids))
    return _api("host.update", {"hostid": host_id, "templates": [{"templateid": t} for t in merged]})


@mcp.tool
def zabbix_set_host_macro(host_id: str, macro: str, value: str, description: str = "") -> Any:
    """Cria ou atualiza macro de host, por exemplo {$SNMP_COMMUNITY}."""
    if not (macro.startswith("{") and macro.endswith("}")):
        raise ValueError("Macro deve ter formato {$NOME}.")
    found = _api("usermacro.get", {"hostids": [host_id], "filter": {"macro": macro}, "output": "extend"})
    if found:
        return _api("usermacro.update", {"hostmacroid": found[0]["hostmacroid"], "value": value, "description": description})
    return _api("usermacro.create", {"hostid": host_id, "macro": macro, "value": value, "description": description})


@mcp.tool
def zabbix_create_item(
    host_id: str,
    name: str,
    key: str,
    item_type: int,
    value_type: int,
    delay: str = "1m",
    interface_id: str = "",
    units: str = "",
    history: str = "7d",
    trends: str = "365d",
) -> Any:
    """Cria item. Tipos e value_type seguem os codigos da API Zabbix 7.0."""
    params: dict[str, Any] = {
        "hostid": host_id, "name": name, "key_": key, "type": item_type,
        "value_type": value_type, "delay": delay, "history": history,
    }
    if value_type in {0, 3}:
        params["trends"] = trends
    if interface_id:
        params["interfaceid"] = interface_id
    if units:
        params["units"] = units
    return _api("item.create", params)


@mcp.tool
def zabbix_create_trigger(
    name: str,
    expression: str,
    priority: int = 3,
    description: str = "Criada pelo WSConnect Zabbix MCP",
    recovery_expression: str = "",
) -> Any:
    """Cria trigger. priority: 0 not classified, 1 information, 2 warning, 3 average, 4 high, 5 disaster."""
    params: dict[str, Any] = {
        "description": name,
        "expression": expression,
        "priority": priority,
        "comments": description,
    }
    if recovery_expression:
        params["recovery_mode"] = 1
        params["recovery_expression"] = recovery_expression
    return _api("trigger.create", params)


@mcp.tool
def zabbix_list_problems(min_severity: int = 0, limit: int = 100) -> Any:
    """Lista problemas recentes, do mais novo para o mais antigo."""
    return _api("problem.get", {
        "output": "extend", "selectAcknowledges": "extend", "selectTags": "extend",
        "severities": list(range(min_severity, 6)), "sortfield": ["eventid"],
        "sortorder": "DESC", "limit": limit,
    })


@mcp.tool
def zabbix_create_map(name: str, width: int = 1200, height: int = 800, label_type: int = 0) -> Any:
    """Cria um mapa vazio. Depois use zabbix_update_map para adicionar elementos e links."""
    return _api("map.create", {"name": name, "width": width, "height": height, "label_type": label_type})


@mcp.tool
def zabbix_update_map(map_id: str, elements: list[dict[str, Any]], links: list[dict[str, Any]]) -> Any:
    """Substitui/adiciona elementos e links do mapa usando o formato da API map.update."""
    return _api("map.update", {"sysmapid": map_id, "selements": elements, "links": links})


@mcp.tool
def zabbix_raw_call(method: str, params_json: str = "{}", destructive: bool = False) -> Any:
    """Executa metodo JSON-RPC nao coberto. Operacoes destrutivas exigem ALLOW_DANGEROUS=true."""
    lowered = method.lower()
    if destructive or lowered.endswith(".delete"):
        _require_dangerous(method)
    params = json.loads(params_json)
    if not isinstance(params, (dict, list)):
        raise ValueError("params_json deve representar objeto ou lista JSON.")
    return _api(method, params)


if __name__ == "__main__":
    transport = os.getenv("MCP_TRANSPORT", "http").lower()
    if transport == "stdio":
        mcp.run()
    else:
        mcp.run(transport="http", host=os.getenv("MCP_HOST", "0.0.0.0"), port=int(os.getenv("MCP_PORT", "8000")))
